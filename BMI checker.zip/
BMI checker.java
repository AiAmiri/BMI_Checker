import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
		System.out.println("BMI checker");
		System.out.println("");
		Scanner input = new Scanner(System.in);
		double x,y;
		System.out.println("enter your weight in KG");
		x = input.nextDouble();
		System.out.println("enter your height in meter");
	    y = input.nextDouble();
		double z = x/y*y;
		if (z<18.5) {
		    System.out.println("BMI is under of 18.5 (you are underweight)");
		}
		else if (25>=z && z>18.5) {
		    System.out.println("BMI is  between of 25 and 18.5  (you are normal)");
		}
		else if (30>=z && z>25) {
		    System.out.println("BMI is  between of 30 and 25  (you are overweight)");
		}
		    else if (z>=30) {
		    System.out.println("BMI is  greeter than 30  (you are obesel)");
		    }
	}
}